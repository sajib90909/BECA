<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class unites extends Model
{
    protected $fillable = [
        'unite_name','description'
    ];
}
