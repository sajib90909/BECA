<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserEducationProfession extends Model
{
    //
}
