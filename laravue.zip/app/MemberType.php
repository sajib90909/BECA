<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MemberType extends Model
{
    //
}
