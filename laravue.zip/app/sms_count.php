<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sms_count extends Model
{
    //
}
