<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class doc_verification_need extends Model
{
    //
}
