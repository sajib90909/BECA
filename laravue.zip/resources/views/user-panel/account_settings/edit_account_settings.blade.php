@extends('user-panel.master')

@section('content')

@endsection
