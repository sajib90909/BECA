@extends('admin-panel.master')
@section('title')
    Help query
@stop
