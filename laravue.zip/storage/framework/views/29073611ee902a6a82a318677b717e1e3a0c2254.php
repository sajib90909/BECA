<?php $__env->startSection('title'); ?>
    Payments
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Row -->
    <div class="row">

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="?" class="text-decoration-none">
                <div class="card border-left-primary shadow h-100 py-2 bg-primary">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Total Recived</div>
                                <div class="h5 mb-0 font-weight-bold text-light">$<?php echo e($all_payment); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-calendar fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <?php if($withdraw != 'not_approve' || $withdraw == 0): ?>
        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card bg-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Balance</div>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <div class="h5 mb-0 mr-3 font-weight-bold text-light">$<?php echo e($balance); ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="?filter=donation" class="text-decoration-none">
                <div class="card bg-dark shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Donation Recived</div>
                                <div class="row no-gutters align-items-center">
                                    <div class="col-auto">
                                        <div class="h5 mb-0 mr-3 font-weight-bold text-light">$<?php echo e($donation_payment); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="?filter=membership" class="text-decoration-none">
                <div class="card bg-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Membership Payment</div>
                                <div class="row no-gutters align-items-center">
                                    <div class="col-auto">
                                        <div class="h5 mb-0 mr-3 font-weight-bold text-light">$<?php echo e($membership_payment); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>

        <?php if($withdraw != 'not_approve' || $withdraw == 0): ?>
        <!-- Pending Requests Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="?filter=withdraw" class="text-decoration-none">
                <div class="card bg-danger shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Withdrew</div>
                                <div class="h5 mb-0 font-weight-bold text-light">$<?php echo e($withdraw); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-comments fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <!-- Total Bife member card example -->

        <div class="col-xl-3 col-md-6 mb-4">
            <a href="" class="text-decoration-none" data-toggle="modal" data-target="#exampleModal">
                <div class="card bg-secondary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Create New Withdrow</div>
                                <div class="h5 mb-0 font-weight-bold text-light">++++</div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-comments fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    <?php endif; ?>



















        <!-- Total Rejected Member Example Card -->
















    </div>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <span class="text-success"><?php echo e(Session::get('message')); ?></span>
            <?php if($payment_table_data == 'undefined'): ?>
                <h6 class="m-0 font-weight-bold text-primary">Withdraw Details</h6>
            <?php else: ?>
                <h6 class="m-0 font-weight-bold text-primary">Payment Details</h6>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <?php if($payment_table_data == 'undefined'): ?>
                    <table class="table table-bordered table-sm" id="dataTable" width="100%" cellspacing="0">

                        <thead>
                        <tr>
                            <th>SN</th>
                            <th>Withdraw by</th>
                            <th>Title</th>
                            <th>Amount</th>
                            <th>Purpose</th>
                            <th>Date</th>
                            <th>action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($withdraws->firstItem() + $key); ?></td>
                                <td><?php echo e($data->name); ?></td>
                                <td><?php echo e($data->withdraw_title); ?></td>
                                <td><?php echo e($data->amount); ?></td>
                                <td><?php echo e($data->purpose); ?></td>
                                <td><?php echo e($data->created_at); ?></td>
                                <td><a href="<?php echo e(route('admin_panel/delete/withdraw/action',['target'=>$data->id])); ?>" class="badge badge-secondary">Cancel & Delete</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <?php echo e($withdraws->links()); ?>

                <?php else: ?>
                    <table class="table table-bordered table-sm" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th>SN</th>
                            <th>Name</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Purpose</th>
                            <th>Date</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $payment_table_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($payment_table_data->firstItem() + $key); ?></td>
                                <td><?php echo e($data->name); ?></td>
                                <td><?php echo e($data->payment_amount); ?></td>
                                <td><?php echo e($data->method); ?></td>
                                <td><?php echo e($data->payment_for); ?></td>
                                <td><?php echo e($data->payment_date); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <?php echo e($payment_table_data->links()); ?>

                <?php endif; ?>

            </div>
        </div>
    </div>
    <?php if($withdraw != 'not_approve' || $withdraw == 0): ?>
    <!-- Button trigger modal -->
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Withdraw</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php echo Form::open(['route' => 'admin_panel/add/withdraw/action', 'method' => 'post','class' => 'py-lg-2']); ?>

                <div class="modal-body">
                    <div class="">
                        <div class="form-group">
                            <label for="withdraw_title">Withdraw Title</label>
                            <input type="text" class="form-control" name="withdraw_title" id="withdraw_title" value="<?php echo e(old('withdraw_title')); ?>" placeholder="Enter withdraw title">
                            <span class="text-danger"><?php echo e($errors->has('withdraw_title')? $errors->first('withdraw_title') : ''); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="amount">Withdraw amount</label>
                            <input type="number" class="form-control" name="amount" id="amount" value="<?php echo e(old('amount')); ?>" placeholder="Enter Amount">
                            <span class="text-danger"><?php echo e($errors->has('amount')? $errors->first('amount') : ''); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="purpose">description</label>
                            <textarea class="form-control" name="purpose" id="purpose" rows="3"><?php echo e(old('purpose')); ?></textarea>
                            <span class="text-danger"><?php echo e($errors->has('purpose')? $errors->first('purpose') : ''); ?></span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-dark">Confirm</button>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/admin-panel/payments/payment.blade.php ENDPATH**/ ?>