<?php $__env->startSection('title'); ?>
  <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Content <span class="badge badge-primary"><?php echo e($action); ?></span></h6>
                </div>
                <div class="card-body">
                    <span class="text-success"><?php echo e(Session::get('message')); ?></span>
                    <?php if($action == 'logo'): ?>
                        <?php echo Form::open(['route' => '/admin_panel/action/custom_page', 'method' => 'post','class' => 'py-lg-2','enctype'=>'multipart/form-data']); ?>

                        <div class="form-group">
                            <div class="image-logo">
                                <img src="<?php echo e(asset('/admin-panel')); ?><?php echo e((!empty($content_data)) ? '/'.$content_data->content_details : '/site_uploads/thumb.jpg'); ?>" alt="Responsive image" class="img-thumbnail">
                            </div>
                            <input type="text" required hidden name="action" value="logo">
                            <label for="exampleFormControlTextarea1">Change Logo</label>
                            <input required type="file" class="form-control" name="logo">
                            <span class="text-danger"><?php echo e($errors->has('logo')? $errors->first('logo') : ''); ?></span>
                            <div>
                                <span class="">Last Update By: <span class="text-success"><?php echo e(($update_by) ? $update_by : ''); ?></span></span>
                            </div>
                        </div>
                        <input class="btn btn-success mt-2" type="submit" name="" value="Update">
                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <?php echo Form::open(['route' => '/admin_panel/action/custom_page', 'method' => 'post','class' => 'py-lg-2']); ?>

                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Add Content</label>
                            <input type="text" required hidden name="action" value="<?php echo e($action); ?>">
                            <textarea required class="form-control" name="description" rows="7" id="<?php echo e(($action == 'head_notice') ? '': 'content_area_id'); ?>"><?php echo e(($content_data)? $content_data->content_details:''); ?></textarea>
                            <span class="text-danger"><?php echo e($errors->has('description')? $errors->first('description') : ''); ?></span>
                            <div>
                                <span class="">Last Update By: <span class="text-success"><?php echo e(($update_by) ? $update_by : ''); ?></span></span>
                            </div>
                        </div>
                        <input class="btn btn-success float-right mt-2" type="submit" name="" value="Update">
                        <?php echo Form::close(); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        CKEDITOR.replace('content_area_id', {
            filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/admin-panel/content/content.blade.php ENDPATH**/ ?>