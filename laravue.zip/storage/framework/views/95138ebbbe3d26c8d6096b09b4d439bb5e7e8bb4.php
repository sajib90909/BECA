<?php $__env->startSection('title'); ?>
    Admins
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Row -->
    <div class="row">

        <!-- Create Admin Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a class="text-white" href="<?php echo e(route('/admin_panel/add/unite')); ?>" title="">
                <div class="card shadow h-100 py-2 bg-light">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-dark text-uppercase mb-1">Create New Unite</div>
                                <div class="h5 mb-0 font-weight-bold text-dark">++</div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-user fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card shadow h-100 py-2 bg-info">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Total unite</div>
                            <div class="h5 mb-0 font-weight-bold text-light">3 Unite</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-user fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- DataTales Example -->
        <div class="card shadow mb-4 ml-2">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Admin Users Details</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th>SN</th>
                            <th>Unite Name</th>
                            <th>Description</th>
                            <th>Total unit Member</th>
                            <th>total unit admins</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>1</td>
                            <td>01751333993</td>
                            <td>admin@gmail.com</td>
                            <td>12/12/12</td>
                            <td>Unite Admin</td>
                            <td>
                                <i class="fas fa-globe-americas text-success"></i>
                                Active <br>
                                <small>Last login D:1/1/20 T:19:02:23</small>
                            </td>
                            <td>
                                <a href="" title="">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>01400647847</td>
                            <td>admin@gmail.com</td>
                            <td>12/12/12</td>
                            <td>Supper Admin</td>
                            <td>
                                <i class="fas fa-globe-americas"></i>
                                Stop <br>
                                <small>Last login D:1/1/20 T:19:02:23</small>
                            </td>
                            <td>
                                <a href="" title="">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/admin-panel/unites/unite.blade.php ENDPATH**/ ?>