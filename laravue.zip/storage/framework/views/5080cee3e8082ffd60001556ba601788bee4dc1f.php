<?php $__env->startSection('title'); ?>
    Contact Infos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main Content -->
    <div id="content">

    <!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Contract Information</h1>
                <a href="<?php echo e(route('customer.printpdf')); ?>" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Print</a>
            </div>

        </div>
        <!-- /.container-fluid -->


        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <div class="d-block">
                        <span class="text-success"><?php echo e(Session::get('message')); ?></span>
                        <span class="text-danger"><?php echo e(Session::get('error_message')); ?></span>
                    </div>
                    <h6 class="m-0 font-weight-bold text-primary d-inline-block">Contract Information Details</h6>
                    <?php if($contact_details->check == 1): ?>
                        <a class="d-none d-sm-inline-block btn btn-sm btn-outline-primary disabled shadow-sm float-right d-inline-block">Locked</a>
                    <?php else: ?>
                        <a class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm float-right d-inline-block" href="<?php echo e(route('/user_panel/user_details/contact_details/edit')); ?>" title="">Edit</a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <table class="table table-borderless details-show">
                                <tbody>
                                <tr>
                                    <td class="font-weight-bold">Email Address</td>
                                    <td>: <?php echo ($contact_details->email) ? $contact_details->email : '<span class="text-danger">empty</span>'; ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Secondary Number</td>
                                    <td>: <?php echo ($contact_details->secondary_number) ? $contact_details->secondary_number : '<span class="text-danger">empty</span>'; ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Emergency Number</td>
                                    <td>: <?php echo ($contact_details->emergency_number) ? $contact_details->emergency_number : '<span class="text-danger">empty</span>'; ?></td>
                                </tr>

                                </tbody>
                            </table>
                        </div>
                        <div class="col-lg-6">
                            <table class="table table-borderless details-show">
                                <tbody>
                                <tr>
                                    <td class="font-weight-bold">Facebook ID</td>
                                    <td>: <?php echo ($contact_details->facebook) ? $contact_details->facebook : '<span class="text-danger">empty</span>'; ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Twitter ID</td>
                                    <td>: <?php echo ($contact_details->twitter) ? $contact_details->twitter : '<span class="text-danger">empty</span>'; ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Skype ID</td>
                                    <td>: <?php echo ($contact_details->skype) ? $contact_details->skype : '<span class="text-danger">empty</span>'; ?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/user-panel/contact_info/contact_info.blade.php ENDPATH**/ ?>