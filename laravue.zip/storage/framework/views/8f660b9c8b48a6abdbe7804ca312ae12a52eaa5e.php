<?php $__env->startSection('title'); ?>
    Update Unite
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4 col-lg-6 col-xl-4">
        <div class="py-3">
            <div class="">
                <?php echo Form::open(['route' => 'admin_panel/edit/action/unite', 'method' => 'post','class' => 'py-lg-2']); ?>

                <input type="number" hidden required value="<?php echo e($unite->id); ?>" name="unite_id">
                <div class="form-group">
                    <label for="exampleFormControlInput1">Unite Name</label>
                    <input type="text" class="form-control" name="unite_name" id="exampleFormControlInput1" value="<?php echo e(!empty(old('unite_name')) ? old('unite_name'): $unite->unite_name); ?>" placeholder="Enter Unite Name">
                    <span class="text-danger"><?php echo e($errors->has('unite_name')? $errors->first('unite_name') : ''); ?></span>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Add description <small>(optional)</small></label>
                    <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="3"><?php echo e(!empty(old('description')) ? old('description'): $unite->description); ?></textarea>
                    <span class="text-danger"><?php echo e($errors->has('description')? $errors->first('description') : ''); ?></span>
                </div>
                <input class="btn btn-success mt-2" type="submit" name="" value="Update">
                <a class="btn btn-dark float-right mt-2" href="<?php echo e(route('/admin_panel/add/unite')); ?>">Back</a>
                <?php echo Form::close(); ?>


            </div>
            <div class="col-lg-4"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/admin-panel/update/updateUnite.blade.php ENDPATH**/ ?>