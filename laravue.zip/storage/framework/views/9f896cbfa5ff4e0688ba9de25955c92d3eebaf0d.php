<?php $__env->startSection('title'); ?>
    Contact Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-4">
        <div class="">
            <a class="text-light" href="<?php echo e(route('/')); ?>">
                <p class="my-2 font-weight-bold btn btn-success ">Home</p>
            </a>
        </div>
        <div>
            <div class="pb-md-4">
                <h3 class="text-center">About Contact</h3>
            </div>
            <div class="pr-md-2 pl-md-2">
                <?php echo !empty($content_data) ? $content_data->content_details : 'no data'; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('members.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/members/others/contact.blade.php ENDPATH**/ ?>