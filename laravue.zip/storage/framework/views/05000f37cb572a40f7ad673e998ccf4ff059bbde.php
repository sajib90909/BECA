<?php $__env->startSection('title'); ?>
    Documents
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main Content -->
    <div id="content">
    <!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Verification Document</h1>
                <a href="<?php echo e(route('customer.printpdf')); ?>" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Print</a>
            </div>

        </div>
        <!-- /.container-fluid -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <div class="d-block">
                        <span class="text-success"><?php echo e(Session::get('message')); ?></span>
                        <span class="text-danger"><?php echo e(Session::get('error_message')); ?></span>
                    </div>
                    <h6 class="m-0 font-weight-bold text-primary d-inline-block">Verification Document Details</h6>
                    <?php if($verification_docs->check == 1): ?>
                        <a class="d-none d-sm-inline-block btn btn-sm btn-outline-primary disabled shadow-sm float-right d-inline-block">Locked</a>
                    <?php else: ?>
                        <a class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm float-right d-inline-block" href="<?php echo e(route('/user_panel/user_details/document_details/edit')); ?>" title="">Edit</a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6 table-responsive">
                            <table class="table table-borderless details-show">
                                <tbody>
                                <tr class="border-bottom">
                                    <td class="font-weight-bold">NID/Passport</td>
                                    <td>: <?php echo ($verification_docs->user_nid_pass_doc) ? str_replace("uploaded_document/","",$verification_docs->user_nid_pass_doc) : '<span class="text-danger">empty</span>'; ?></td>
                                    <?php if($verification_docs->user_nid_pass_doc): ?>
                                        <td><a target="_blank" href="<?php echo e(route('user_panel/view/',['action'=>'user_nid_pass_doc'])); ?>" class="btn btn-sm btn-light btn-outline-dark">view</a></td>
                                        <td><a href="<?php echo e(route('user_panel/download/',['action'=>'user_nid_pass_doc'])); ?>" class="btn btn-sm btn-light btn-outline-dark">download</a></td>
                                    <?php endif; ?>

                                </tr>
                                <tr class="border-bottom">
                                    <td class="font-weight-bold">Cadet Certificate</td>
                                    <td>: <?php echo ($verification_docs->user_cadet_certificate_doc) ? str_replace("uploaded_document/","",$verification_docs->user_cadet_certificate_doc) : '<span class="text-danger">empty</span>'; ?></td>
                                    <?php if($verification_docs->user_cadet_certificate_doc): ?>
                                        <td><a target="_blank" href="<?php echo e(route('user_panel/view/',['action'=>'user_cadet_certificate_doc'])); ?>" class="btn btn-sm btn-light btn-outline-dark">view</a></td>
                                        <td><a href="<?php echo e(route('user_panel/download/',['action'=>'user_cadet_certificate_doc'])); ?>" class="btn btn-sm btn-light btn-outline-dark">download</a></td>
                                    <?php endif; ?>
                                </tr>
                                <tr class="border-bottom">
                                    <td class="font-weight-bold">Beca Documents</td>
                                    <td>: <?php echo ($verification_docs->user_beca_doc) ? str_replace("uploaded_document/","",$verification_docs->user_beca_doc) : '<span class="text-danger">empty</span>'; ?></td>
                                    <?php if($verification_docs->user_beca_doc): ?>
                                        <td><a target="_blank" href="<?php echo e(route('user_panel/view/',['action'=>'user_beca_doc'])); ?>" class="btn btn-sm btn-light btn-outline-dark">view</a></td>
                                        <td><a href="<?php echo e(route('user_panel/download/',['action'=>'user_beca_doc'])); ?>" class="btn btn-sm btn-light btn-outline-dark">download</a></td>
                                    <?php endif; ?>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/user-panel/verification_doc/verification_doc.blade.php ENDPATH**/ ?>