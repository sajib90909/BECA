<?php $__env->startSection('content'); ?>
    <!-- Main Content -->

    <div id="content">
        <!-- Begin Page Content -->
        <div class="modal-backdrop fade show nw-overlay"></div>
        <div class="container-fluid parent-all-form">
            <div class="card form-all">
                <div class="card-body">
                    <div class="border-bottom">
                        <h4 class="text-primary">You need to Verify your documents</h4>
                    </div>
                    <div class="text-right">
                        <a class="dropdown-item" href="<?php echo e(route('/logout/action')); ?>"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i> <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('/logout/action')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                    <div class="">
                        <?php echo Form::open(['route' => '/user_panel/first_login/document_details/edit/action', 'method' => 'post', 'enctype'=>'multipart/form-data']); ?>

                        <div class="row p-lg-4 p-md-2">
                            <div class="col-lg-6">
                                <div class="form-group row">
                                    <label for="form-input-user_nid_pass_doc" class="col-sm-3 col-form-label">NID/Passport<?php echo ($doc_need->user_nid_pass_doc == 1)? '<span class="text-danger h5">*</span>' : ''; ?></label>
                                    <div class="col-sm-9">
                                        <input <?php echo e(($doc_need->user_nid_pass_doc == 1)? 'required' : ''); ?> required type="file" name="user_nid_pass_doc" class="form-control col-md-8" id="form-input-user_nid_pass_doc">
                                        <span class="text-danger"><?php echo e($errors->has('user_nid_pass_doc')? $errors->first('user_nid_pass_doc') : ''); ?></span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="form-input-user_cadet_certificate_doc" class="col-sm-3 col-form-label">Cadet Certificate<?php echo ($doc_need->user_cadet_certificate_doc == 1)? '<span class="text-danger h5">*</span>' : ''; ?></label>
                                    <div class="col-sm-9">
                                        <input type="file" <?php echo e(($doc_need->user_cadet_certificate_doc == 1)? 'required' : ''); ?> name="user_cadet_certificate_doc" class="form-control col-md-8" id="form-input-user_cadet_certificate_doc">
                                        <span class="text-danger"><?php echo e($errors->has('user_cadet_certificate_doc')? $errors->first('user_cadet_certificate_doc') : ''); ?></span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="form-input-user_beca_doc" class="col-sm-3 col-form-label">Beca Documents<?php echo ($doc_need->user_beca_doc == 1)? '<span class="text-danger h5">*</span>' : ''; ?></label>
                                    <div class="col-sm-9">
                                        <input type="file" <?php echo e(($doc_need->user_beca_doc == 1)? 'required' : ''); ?> name="user_beca_doc" class="form-control col-md-8" id="form-input-user_beca_doc">
                                        <span class="text-danger"><?php echo e($errors->has('user_beca_doc')? $errors->first('user_beca_doc') : ''); ?></span>
                                    </div>
                                </div>

                            </div>

                            <div class="pt-4 pl-2 border-top w-75">
                                <button type="submit" class="btn btn-info mb-2 w-50">Submit</button>
                            </div>

                        </div>

                        <?php echo Form::close(); ?>

                    </div>


                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/user-panel/first_login/document.blade.php ENDPATH**/ ?>