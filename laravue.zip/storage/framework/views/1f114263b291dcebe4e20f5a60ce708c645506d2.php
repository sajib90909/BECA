<?php $__env->startSection('content'); ?>
    <div class="p-4">
        <div class="">
            <a class="text-light" href="<?php echo e(route('/')); ?>">
                <p class="my-2 font-weight-bold btn btn-success ">Home</p>
            </a>
        </div>
        <div>
            <h4 class="text-center">Verify Phone Number</h4>
        </div>
        <div class="p-2 rounded text-center text-gray-600">
            <p >A verification code send your phone number. if you not get any Code please wait 5 minute!</p>
        </div>
        <div class="w-customs bg-light p-2 rounded m-auto">
            <?php echo Form::open(['route' => '/registration/phoneVerify/action', 'method' => 'post']); ?>

            <div class="form-group">
                <label>Code</label>
                <input required type="number" class="form-control form-control-sm" name="code" placeholder="Enter Code to Confirm">
                <span class="text-danger"><?php echo e($errors->has('code')? $errors->first('code') : ''); ?></span>
            </div>
            <input required hidden type="text" name="otp" value="<?php echo e($otp); ?>">
            <input required hidden type="text" name="name" value="<?php echo e($name); ?>">
            <input required hidden type="text" name="phone" value="<?php echo e($phone); ?>">
            <input required hidden type="password" name="password" value="<?php echo e($password); ?>">
            <input required hidden type="number" name="current_unite" value="<?php echo e($current_unite); ?>">
            <input required hidden type="password" name="password_confirmation" value="<?php echo e($password); ?>">
            <div class=" text-right">
                <button type="submit" name="login_action" class="btn btn-success btn-sm">Verify</button>
            </div>
            <?php echo Form::close(); ?>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('members.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/members/auth/phoneVerify.blade.php ENDPATH**/ ?>