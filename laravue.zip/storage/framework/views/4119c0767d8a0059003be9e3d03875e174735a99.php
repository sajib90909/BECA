<?php $__env->startSection('title'); ?>
    Help
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main Content -->
    <div id="content">

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Feel free to contact with us</h1>
            </div>

        </div>
        <!-- /.container-fluid -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary d-inline-block"><span class="badge badge-success">Help</span></h6>
                </div>
                <div class="card-body">
                    <div class="">
                        <?php echo isset($content_data->content_details) ? $content_data->content_details : 'no data'; ?>

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/user-panel/help.blade.php ENDPATH**/ ?>