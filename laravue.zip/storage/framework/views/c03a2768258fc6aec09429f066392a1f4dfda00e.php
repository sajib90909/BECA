<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Row -->
    <div class="row">

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2 bg-primary">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Total MEMBER'S</div>
                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo e($count_all_number); ?></div>

                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card bg-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Payment</div>
                            <div class="h5 mb-0 font-weight-bold text-light">$<?php echo e($count_payment); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-light"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card bg-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Notice</div>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <div class="h5 mb-0 mr-3 font-weight-bold text-light"><?php echo e($notice_count); ?></div>

                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pending Requests Card Example -->
        <?php if($admin_count != 'not_approve'): ?>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card bg-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Admin/Unite User's</div>
                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo e($admin_count); ?></div>

                        </div>
                        <div class="col-auto">
                            <i class="fas fa-user-friends fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <!-- Pending Requests Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card bg-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-light text-uppercase mb-1">SMS</div>
                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo e($sms_count); ?></div>

                        </div>
                        <div class="col-auto">
                            <i class="fas fa-comments fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if($active_logs != 'not_approve'): ?>
        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <span class="text-success" ><?php echo e(Session::get('message')); ?></span>
                <h6 class="m-0 font-weight-bold text-primary">Admins Active Logs</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <form class="form-inline" action="<?php echo e(route('/admin_panel')); ?>" method="get">
                        <div class="form-group mb-2 mr-2">
                            <select name="active_log" class="form-control form-control-sm">
                                <option value="">select Admin</option>
                                <?php $__currentLoopData = $active_logs_admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $active_logs_admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($active_logs_admin->action_admin_id); ?>"><?php echo e($active_logs_admin->admin_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary mb-2 btn-sm">Filter</button>
                    </form>
                    <table class="table table-striped table-sm d-inline-block" id="dataTable">
                        <tbody>
                        
                        <?php $__currentLoopData = $active_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $active_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($active_logs->firstItem() + $key); ?></td>
                                <td class="pl-4 pr-4">
                                    <small class="">
                                        <a href="" class="badge badge-info"><?php echo e(($active_log->action_admin_id == Session::get('admin_id'))? 'you' :$active_log->admin_name); ?> </a>
                                    <?php echo e($active_log->action_details); ?>

                                        <a href="" class="badge badge-secondary"><?php echo e(($active_log->user_name) ? $active_log->user_name :
                                                    (($active_log->type_name) ? $active_log->type_name :
                                                    (($active_log->member_name) ? $active_log->member_name :
                                                    (($active_log->unite_name) ? $active_log->unite_name :
                                                    (($active_log->user_type == 'sms') ? 'show' :
                                                    (($active_log->user_type == 'notice') ? 'show' : '')))))); ?></a>
                                    </small>
                                </td>
                                <td><?php echo e(\Carbon\Carbon::parse($active_log->created_at)->diffForHumans()); ?></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($active_logs->links()); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/admin-panel/dashboard/dashboard.blade.php ENDPATH**/ ?>