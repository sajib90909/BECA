<?php $__env->startSection('title'); ?>
    Help query
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/admin-panel/help/help.blade.php ENDPATH**/ ?>