<?php $__env->startSection('title'); ?>
    Edit '<?php echo strtolower($members_name->name); ?>' Beca Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow p-2">
        <?php echo Form::open(['route' => '/admin_panel/members/beca_details/edit/action', 'method' => 'post', 'enctype'=>'multipart/form-data']); ?>

        <div class="row p-lg-4 p-md-2">
            <input type="number" name="user_id" value="<?php echo e($beca_details->user_id); ?>" hidden>
            <div class="col-lg-6">
                <div class="form-group row">
                    <label for="form-input-members_type" class="col-sm-3 col-form-label">Members type<span class="text-danger h5">*</span></label>
                    <div class="col-sm-9">
                        <select required class="form-control col-md-8" name="members_type" id="form-input-members_type" size="1">
                            <option value="" selected="selected">Select Members Type</option>
                            <?php $__currentLoopData = $members_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($m_type ->id); ?>"><?php echo e($m_type ->type_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="text-danger"><?php echo e($errors->has('members_type')? $errors->first('members_type') : ''); ?></span>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="form-input-current_unite" class="col-sm-3 col-form-label">Current Unite<span class="text-danger h5">*</span></label>
                    <div class="col-sm-9">
                        <select required class="form-control col-md-8" name="current_unite" id="form-input-current_unite" size="1">
                            <option value="" selected="selected">Select Current Unite</option>
                            <?php $__currentLoopData = $unites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($unite ->id); ?>"><?php echo e($unite->unite_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="text-danger"><?php echo e($errors->has('current_unite')? $errors->first('current_unite') : ''); ?></span>
                    </div>
                </div>

                <fieldset class="form-group">
                    <div class="row">
                        <legend class="col-form-label col-sm-3 pt-0">NEC Member</legend>
                        <div class="col-sm-9">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="nec_member" id="gridRadios1" <?php echo e((old('nec_member')) ? ((old('nec_member') == 1) ? 'checked' :'') : (($beca_details->nec_member == 1)? 'checked':'')); ?> value="1">
                                <label class="form-check-label" for="gridRadios1">
                                    Yes
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="nec_member" id="gridRadios2" <?php echo e((old('nec_member')) ? ((old('nec_member') == 0) ? 'checked' :'') : (($beca_details->nec_member == 0)? 'checked':'')); ?> value="0">
                                <label class="form-check-label" for="gridRadios2">
                                    No
                                </label>
                            </div>
                        </div>
                    </div>
                </fieldset>
                <div class="form-group row">
                    <label for="form-input-position" class="col-sm-3 col-form-label">Position</label>
                    <div class="col-sm-9">
                        <input type="text" name="position" class="form-control col-md-8" id="form-input-position" value="<?php echo e((old('position')) ? old('position') : $beca_details->position); ?>" placeholder="Enter Members beca position">
                        <span class="text-danger"><?php echo e($errors->has('position')? $errors->first('position') : ''); ?></span>
                    </div>
                </div>


            </div>

            <div class="pt-4 pl-2 border-top w-100">
                <a href="<?php echo e(route('/admin_panel/members/details/',['user_id'=>$beca_details->user_id])); ?>" class="btn btn-dark mb-2">back</a>
                <button type="submit" class="btn btn-info mb-2">Save</button>
            </div>

        </div>

        <?php echo Form::close(); ?>

    </div>
    <script>
        document.getElementById('form-input-members_type').value= '<?php echo e((old('members_type')) ? old('members_type') : $current_members_type->member_type); ?>';
        document.getElementById('form-input-current_unite').value='<?php echo e((old('current_unite')) ? old('current_unite') : $beca_details->current_unite); ?>';
        document.getElementById('form-input-registration_unite').value='<?php echo e((old('registration_unite')) ? old('registration_unite') : $beca_details->registration_unite); ?>';
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/admin-panel/members/editBecaDetails.blade.php ENDPATH**/ ?>