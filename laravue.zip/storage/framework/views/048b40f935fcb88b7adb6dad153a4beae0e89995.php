<?php $__env->startSection('title'); ?>
    Update Your Account
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4 d-inline-block col-lg-6 col-xl-4">
        <div class="py-3">
            <div class="">
                <span class="text-success"><?php echo e(Session::get('message')); ?></span>
                <?php echo Form::open(['route' => 'admin_panel/update/account/action', 'method' => 'post','class' => 'py-lg-2','enctype'=>'multipart/form-data']); ?>

                <div class="form-group">
                    <img src="<?php echo e(asset('admin-panel/'.( ($account_data->image) ? $account_data->image : '/admin_profile_images/thumbnail.png'))); ?>" class="rounded mx-auto d-block w-25 pb-3" alt="img-thumbnail">
                    <label for="profile_image">Profile Image</label>
                    <input type="file" class="form-control" name="image" id="image">
                    <span class="text-danger"><?php echo e($errors->has('image')? $errors->first('image') : ''); ?></span>
                </div>
                <div class="form-group">
                    <label for="fullname">Full Name</label>
                    <input type="text" class="form-control" name="name" id="fullname" value="<?php echo e(!empty(old('name')) ? old('name'): $account_data->name); ?>" placeholder="Enter Full Name">
                    <span class="text-danger"><?php echo e($errors->has('name')? $errors->first('name') : ''); ?></span>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" name="email" id="email" value="<?php echo e(!empty(old('email')) ? old('email'): $account_data->email); ?>" placeholder="Enter Email">
                    <span class="text-danger"><?php echo e($errors->has('email')? $errors->first('email') : ''); ?></span>
                </div>
                <div class="form-group">
                    <label for="form_password">Password</label>
                    <input type="password" class="form-control" name="password" id="form_password" placeholder="Enter Password">
                    <span class="text-danger"><?php echo e($errors->has('password')? $errors->first('password') : ''); ?></span>
                </div>
                <input class="btn btn-success mt-2" type="submit" name="" value="Update">
                <?php echo Form::close(); ?>


            </div>
            <div class="p-4 m-2 rounded border border-danger">
                <h5 class="text-danger">You cant change this information. if you want contact with authorities</h5>
                <div>
                    <span><strong>Unite name:</strong> <?php echo e($unite_name->unite_name); ?></span>
                </div>
                <div>
                    <span><strong>User name:</strong> <?php echo e($account_data->user_name); ?></span>
                </div>
                <div>
                    <span><strong>Phone:</strong> <?php echo e($account_data->phone); ?></span>
                </div>
                <div>
                    <span><strong>Beca id:</strong> <?php echo e($account_data->beca_reg_id); ?></span>
                </div>

            </div>
            <div class="col-lg-4"></div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/admin-panel/admins/accountSettings.blade.php ENDPATH**/ ?>