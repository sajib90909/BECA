<?php $__env->startSection('title'); ?>
    Admins
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Row -->
    <div class="row">

        <!-- Create Admin Card Example -->

















        <div class="col-xl-3 col-md-6 mb-4 userlink">
            <a class="text-decoration-none" href="<?php echo e(route('/admin_panel/add/admin')); ?>" title="">
                <div class="card shadow h-100 py-2 bg-secondary">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Create New Admin</div>
                                <div class="h5 mb-0 font-weight-bold text-light">++</div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-user fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
















        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="?" class="text-decoration-none">
            <div class="card border-left-primary shadow h-100 py-2 bg-primary">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Total Admin User</div>
                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo e($count_admins); ?> Admin</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-user fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
            </a>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="?filter=super_admin" class="text-decoration-none">
                <div class="card bg-success shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Super Admin</div>
                                <div class="h5 mb-0 font-weight-bold text-light"><?php echo e($count_s_admins); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-user-secret fa-2x text-light"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="?filter=unite_admin" class="text-decoration-none">
                <div class="card bg-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Unite Admin</div>
                                <div class="row no-gutters align-items-center">
                                    <div class="col-auto">
                                        <div class="h5 mb-0 mr-3 font-weight-bold text-light"><?php echo e($count_u_admins); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-user-graduate fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="?filter=trash" class="text-decoration-none">
                <div class="card bg-danger shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-light text-uppercase mb-1">Trash</div>
                                <div class="row no-gutters align-items-center">
                                    <div class="col-auto">
                                        <div class="h5 mb-0 mr-3 font-weight-bold text-light"><?php echo e($count_trash); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-user-graduate fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>

    </div>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <span class="text-success" ><?php echo e(Session::get('message')); ?></span>
            <h6 class="m-0 font-weight-bold text-primary">Admin Users Details</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>SN</th>
                        <th>User ID</th>
                        <th>Picture</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Beca Id</th>
                        <th>Type</th>
                        <th>Unite</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($admins->firstItem() + $key); ?></td>
                            <td><?php echo e($admin->user_name); ?></td>
                            <td><img style="width: 100px;" src="<?php echo e(asset('/admin-panel/'.(!empty($admin->image) ? $admin->image: 'admin_profile_images/thumbnail.png'))); ?>" alt=""></td>
                            <td><?php echo e($admin->name); ?></td>
                            <td><?php echo e($admin->email); ?></td>
                            <td><?php echo e($admin->phone); ?></td>
                            <td><?php echo e($admin->beca_reg_id); ?></td>
                            <td><?php echo e($admin->user_type); ?></td>
                            <td><?php echo e($admin->unite_name); ?></td>
                            <td>
                                <?php if($admin->status == 1): ?>
                                    <i class="fas fa-globe-americas text-success"></i>
                                    Active <br>
                                <?php elseif($admin->status == 0): ?>
                                    <i class="fas fa-globe-americas"></i>
                                    Mute <br>
                                <?php else: ?>
                                    <i class="fas fa-globe-americas text-danger"></i>
                                    Trash <br>
                                <?php endif; ?>

                            </td>
                            <td>
                                <?php if(($admin->user_type == 'super_admin') && (Session::get('admin_type') != 'author')): ?>

                                <?php else: ?>
                                <?php if($admin->status == 1): ?>
                                    <a href="<?php echo e(route('/admin_panel/admins/mute',['admin_id'=>$admin->id])); ?>">
                                        <i class="fas fa-arrow-alt-circle-down text-dark mr-2"></i>
                                    </a>
                                <?php else: ?>
                                     <a href="<?php echo e(route('/admin_panel/admins/active',['admin_id'=>$admin->id])); ?>">
                                        <i class="fas fa-arrow-alt-circle-up text-success mr-2"></i>
                                     </a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('/admin_panel/update/admin',['admin_id'=>$admin->id])); ?>">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>
                                    <?php if($admin->status != 2): ?>
                                        <a class="pl-2" href="<?php echo e(route('/admin_panel/admins/trash',['admin_id'=>$admin->id])); ?>">
                                            <i class="fas fa-trash-restore-alt text-danger"></i>
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($admins->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/admin-panel/admins/admins.blade.php ENDPATH**/ ?>