<?php $__env->startSection('title'); ?>
    ADD Unite
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4 d-inline-block col-lg-6 col-xl-4">
        <div class="py-3">
            <div class="">
                <span class="text-success"><?php echo e(Session::get('message')); ?></span>
                <?php echo Form::open(['route' => '/admin_panel/newCreate/coupons/action', 'method' => 'post','class' => 'py-lg-2']); ?>

                <div class="form-group">
                    <label for="type_name">Coupon Code</label>
                    <input required readonly type="text" class="form-control" name="code" id="type_name" value="<?php echo e((old('code')) ? old('code') : $couponsCode); ?>">
                    <span class="text-danger"><?php echo e($errors->has('code')? $errors->first('code') : ''); ?></span>
                </div>
                <div class="form-group">
                    <label for="unite_id_id">Member Type</label>
                    <select required class="form-control" name="member_type" id="unite_id_id">
                        <option value="">Select Membership Type</option>
                        <?php $__currentLoopData = $members_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($member_type->id); ?>"><?php echo e($member_type->type_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="text-danger"><?php echo e($errors->has('member_type')? $errors->first('member_type') : ''); ?></span>
                </div>
                <div class="form-group">
                    <label for="user_phone">Assigned user by phone</label>
                    <input type="text" class="form-control" name="user_phone" id="user_phone" value="<?php echo e(old('user_phone')); ?>" placeholder="Enter user phone number">
                    <span class="text-danger"><?php echo e($errors->has('user_phone')? $errors->first('user_phone') : ''); ?></span>
                </div>
                <?php if(Session::get('admin_type') == 'super' || Session::get('admin_type') == 'author'): ?>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="1" name="receive_cash" id="defaultCheck1" checked>
                    <label class="form-check-label" for="defaultCheck1">
                        Cash Received
                    </label>
                </div>
                <?php endif; ?>
                <div class="form-check mb-4">
                    <input class="form-check-input" type="checkbox" value="1" name="send_code" id="defaultCheck2" checked>
                    <label class="form-check-label" for="defaultCheck2">
                        Send Code to users phone
                    </label>
                </div>
                <input class="btn btn-success mt-2" type="submit" name="" value="Add Coupon">
                <a class="btn btn-dark float-right mt-2" href="<?php echo e(route('/admin_panel/admins')); ?>">Back</a>
                <?php echo Form::close(); ?>


            </div>
            <div class="col-lg-4"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravue\resources\views/admin-panel/coupon/addCoupon.blade.php ENDPATH**/ ?>