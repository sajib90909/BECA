var stateObject = {

        "Barishal" :{

                "Barguna" :["Amtali Upazila","Bamna Upazila","Barguna Sadar Upazila","Betagi Upazila",

                "Patharghata Upazila","Taltali Upazila"],

                "Barishal" :["Muladi Upazila","Babuganj Upazila","Agailjhara Upazila","Barisal Sadar Upazila"

                ,"Bakerganj Upazila","Banaripara Upazila","Gaurnadi Upazila","Hizla Upazila",

                "Mehendiganj Upazila","Wazirpur Upazila"],

                "Bhola" :["Bhola Sadar Upazila","Burhanuddin Upazila","Char Fasson Upazila",

                "Daulatkhan Upazila","Lalmohan Upazila","Manpura Upazila","Tazumuddin Upazila"],

                "Jhalokati" :["Jhalokati Sadar Upazila","Kathalia Upazila","Nalchity Upazila","Rajapur Upazila"],

                "Patuakhali" :["Bauphal Upazila","Dashmina Upazila","Galachipa Upazila",

                "Kalapara Upazila","Mirzaganj Upazila","Patuakhali Sadar Upazila","Dumki Upazila",

                "Rangabali Upazila"],"Pirojpur" :["Bhandaria","Kaukhali","Mathbaria","Nazirpur",

                "Nesarabad","Pirojpur Sadar","Zianagar"]

        },"Chattogram" :{

                "Bandarban" :["Bandarban Sadar","Thanchi","Lama","Naikhongchhari","Ali kadam","Rowangchhari",

                "Ruma"]

                ,"Brahmanbaria" :["Brahmanbaria Sadar Upazila","Ashuganj Upazila","Nasirnagar Upazila",

                "Nabinagar Upazila","Sarail Upazila","Shahbazpur Town","Kasba Upazila","Akhaura Upazila",

                "Bancharampur Upazila","Bijoynagar Upazila"],

                "Chandpur" :["Chandpur Sadar","Faridganj","Haimchar","Haziganj","Kachua","Matlab Uttar",

                "Matlab Dakkhin","Shahrasti"],

                "Chattogram" :["Anwara Upazila","Banshkhali Upazila","Boalkhali Upazila","Chandanaish Upazila",

                "Fatikchhari Upazila","Hathazari Upazila","Lohagara Upazila","Mirsharai Upazila","Patiya Upazila",

                "Rangunia Upazila","Raozan Upazila","Sandwip Upazila","Satkania Upazila","Sitakunda Upazila"],

                "Cumilla" :["Barura Upazila","Brahmanpara Upazila","Burichong Upazila","Chandina Upazila",

                "Chauddagram Upazila","Daudkandi Upazila","Debidwar Upazila","Homna Upazila",

                "Comilla Sadar Upazila","Laksam Upazila","Monohorgonj Upazila","Meghna Upazila",

                "Muradnagar Upazila","Nangalkot Upazila","Comilla Sadar South Upazila","Titas Upazila"],

                "Cox's Bazar" :["Chakaria Upazila","Cox's Bazar Sadar Upazila","Kutubdia Upazila",

                "Maheshkhali Upazila","Ramu Upazila","Teknaf Upazila","Ukhia Upazila","Pekua Upazila"],

                "Feni" :["Feni Sadar","Chagalnaiya","Daganbhyan","Parshuram","Fhulgazi","Sonagazi"],

                "Khagrachhari" :["Dighinala Upazila","Khagrachhari Upazila","Lakshmichhari Upazila",

                "Mahalchhari Upazila","Manikchhari Upazila","Matiranga Upazila","Panchhari Upazila",

                "Ramgarh Upazila"],

                "Lakshmipur" :["Lakshmipur Sadar Upazila","Raipur Upazila","Ramganj Upazila","Ramgati Upazila",

                "Komol Nagar Upazila"],

                "Noakhali" :["Noakhali Sadar Upazila","Begumganj Upazila",

                "Chatkhil Upazila","Companyganj Upazila","Shenbag Upazila","Hatia Upazila","Kobirhat Upazila",

                "Sonaimuri Upazila","Suborno Char Upazila"],

                "Rangamati" :["Rangamati Sadar Upazila","Belaichhari Upazila","Bagaichhari Upazila",

                "Barkal Upazila","Juraichhari Upazila","Rajasthali Upazila","Kaptai Upazila","Langadu Upazila",

                "Nannerchar Upazila","Kaukhali Upazila"]

        },"Dhaka" :{

                "Dhaka" :["Dhamrai Upazila","Dohar Upazila","Keraniganj Upazila","Nawabganj Upazila",

                "Savar Upazila"],

                "Faridpur" :["Faridpur Sadar Upazila","Boalmari Upazila","Alfadanga Upazila",

                "Madhukhali Upazila","Bhanga Upazila","Nagarkanda Upazila","Charbhadrasan Upazila",

                "Sadarpur Upazila","Shaltha Upazila"],

                "Gazipur" :["Gazipur Sadar-Joydebpur","Kaliakior","Kapasia","Sripur","Kaliganj","Tongi"],

                "Gopalganj" :["Gopalganj Sadar Upazila","Kashiani Upazila",

                "Kotalipara Upazila","Muksudpur Upazila","Tungipara Upazila"],

                "Kishoreganj" :["Astagram Upazila","Bajitpur Upazila","Bhairab Upazila","Hossainpur Upazila",

                "Itna Upazila","Karimganj Upazila","Katiadi Upazila","Kishoreganj Sadar Upazila",

                "Kuliarchar Upazila","Mithamain Upazila","Nikli Upazila","Pakundia Upazila","Tarail Upazila"],

                "Madaripur" :["Madaripur Sadar","Kalkini","Rajoir","Shibchar"],

                "Manikganj" :["Manikganj Sadar Upazila","Singair Upazila","Shibalaya Upazila","Saturia Upazila",

                "Harirampur Upazila","Ghior Upazila","Daulatpur Upazila"],

                "Munshiganj" :["Lohajang Upazila","Sreenagar Upazila","Munshiganj Sadar Upazila",

                "Sirajdikhan Upazila","Tongibari Upazila","Gazaria Upazila"],

                "Narayanganj" :["Araihazar Upazila","Sonargaon Upazila","Bandar","Naryanganj Sadar Upazila",

                "Rupganj Upazila","Siddirgonj Upazila"],

                "Narsingdi" :["Belabo Upazila","Monohardi Upazila","Narsingdi Sadar Upazila","Palash Upazila",

                "Raipura Upazila, Narsingdi","Shibpur Upazila"],

                "Rajbari" :["Baliakandi Upazila","Goalandaghat Upazila","Pangsha Upazila","Kalukhali Upazila",

                "Rajbari Sadar Upazila"],

                "Shariatpur" :["Shariatpur Sadar -Palong","Damudya Upazila","Naria Upazila","Jajira Upazila",

                "Bhedarganj Upazila","Gosairhat Upazila"],

                "Tangail" :["Tangail Sadar Upazila","Sakhipur Upazila","Basail Upazila","Madhupur Upazila",

                "Ghatail Upazila","Kalihati Upazila","Nagarpur Upazila","Mirzapur Upazila","Gopalpur Upazila",

                "Delduar Upazila","Bhuapur Upazila","Dhanbari Upazila"]

        },"Khulna" :{

                "Bagerhat" :["Bagerhat Sadar Upazila","Chitalmari Upazila","Fakirhat Upazila","Kachua Upazila",

                "Mollahat Upazila","Mongla Upazila","Morrelganj Upazila","Rampal Upazila","Sarankhola Upazila"],

                "Chuadanga" :["Damurhuda Upazila","Chuadanga-S Upazila","Jibannagar Upazila","Alamdanga Upazila"],

                "Jashore" :["Abhaynagar Upazila","Keshabpur Upazila","Bagherpara Upazila","Jessore Sadar Upazila",

                "Chaugachha Upazila","Manirampur Upazila","Jhikargachha Upazila","Sharsha Upazila"],

                "Jhenaidah" :["Jhenaidah Sadar Upazila","Maheshpur Upazila","Kaliganj Upazila",

                "Kotchandpur Upazila","Shailkupa Upazila","Harinakunda Upazila"]

                ,"Khulna" :["Terokhada Upazila","Batiaghata Upazila","Dacope Upazila","Dumuria Upazila",

                "Dighalia Upazila","Koyra Upazila","Paikgachha Upazila","Phultala Upazila","Rupsa Upazila"],

                "Kushtia" :["Kushtia Sadar","Kumarkhali","Daulatpur","Mirpur","Bheramara","Khoksa"],

                "Magura" :["Magura Sadar Upazila","Mohammadpur Upazila","Shalikha Upazila","Sreepur Upazila"],

                "Meherpur" :["angni Upazila","Mujib Nagar Upazila","Meherpur-S Upazila"],

                "Narail" :["Narail-S Upazilla","Lohagara Upazilla","Kalia Upazilla"],

                "Satkhira" :["Satkhira Sadar Upazila","Assasuni Upazila","Debhata Upazila","Tala Upazila",

                "Kalaroa Upazila","Kaliganj Upazila","Shyamnagar Upazila"]

        },"Rajshahi" :{

                "Bogura" :["Adamdighi","Bogra Sadar","Sherpur","Dhunat","Dhupchanchia","Gabtali","Kahaloo",

                "Nandigram","Sahajanpur","Sariakandi","Shibganj","Sonatala"],

                "Joypurhat" :["Joypurhat S","Akkelpur","Kalai","Khetlal","Panchbibi"],

                "Naogaon" :["Naogaon Sadar Upazila","Mohadevpur Upazila","Manda Upazila","Niamatpur Upazila",

                "Atrai Upazila","Raninagar Upazila","Patnitala Upazila","Dhamoirhat Upazila","Sapahar Upazila",

                "Porsha Upazila","Badalgachhi Upazila"],

                "Natore" :["Natore Sadar Upazila","Baraigram Upazila","Bagatipara Upazila","Lalpur Upazila",

                "Natore Sadar Upazila","Baraigram Upazila"],

                "Chapainawabganj" :["Bholahat Upazila","Gomastapur Upazila","Nachole Upazila",

                "Nawabganj Sadar Upazila","Shibganj Upazila"],

                "Pabna" :["Atgharia Upazila","Bera Upazila","Bhangura Upazila","Chatmohar Upazila",

                "Faridpur Upazila","Ishwardi Upazila","Pabna Sadar Upazila","Santhia Upazila","Sujanagar Upazila"],

                "Rajshahi" :["Bagha","Bagmara","Charghat","Durgapur","Godagari","Mohanpur","Paba",

                "Puthia","Tanore"],

                "Sirajgonj" :["Sirajganj Sadar Upazila","Belkuchi Upazila","Chauhali Upazila",

                "Kamarkhanda Upazila","Kazipur Upazila","Raiganj Upazila","Shahjadpur Upazila",

                "Tarash Upazila","Ullahpara Upazila"]

        },"Rangpur" :{

                "Dinajpur" :["Birampur Upazila","Birganj","Biral Upazila","Bochaganj Upazila",

                "Chirirbandar Upazila","Phulbari Upazila","Ghoraghat Upazila","Hakimpur Upazila",

                "Kaharole Upazila","Khansama Upazila","Dinajpur Sadar Upazila","Nawabganj","Parbatipur Upazila"],

                "Gaibandha" :["Fulchhari","Gaibandha sadar","Gobindaganj","Palashbari","Sadullapur",

                "Saghata","Sundarganj"],

                "Kurigram" :["Kurigram Sadar","Nageshwari","Bhurungamari","Phulbari","Rajarhat","Ulipur",

                "Chilmari","Rowmari","Char Rajibpur"],

                "Lalmonirhat" :["Lalmanirhat Sadar","Aditmari","Kaliganj","Hatibandha","Patgram"],

                "Nilphamari" :["Nilphamari Sadar","Saidpur","Jaldhaka","Kishoreganj","Domar","Dimla"],

                "Panchagarh" :["Panchagarh Sadar","Debiganj","Boda","Atwari","Tetulia"],

                "Rangpur" :["Badarganj","Mithapukur","Gangachara","Kaunia","Rangpur Sadar","Pirgachha",

                "Pirganj","Taraganj"],

                "Thakurgaon" :["Thakurgaon Sadar Upazila","Pirganj Upazila","Baliadangi Upazila",

                "Haripur Upazila","Ranisankail Upazila"]

        },"Sylhet" :{

                "Habiganj" :["Ajmiriganj","Baniachang","Bahubal","Chunarughat","Habiganj Sadar","Lakhai",

                "Madhabpur","Nabiganj","Shaistagonj Upazila"],

                "Moulvibazar" :["Moulvibazar Sadar","Barlekha","Juri","Kamalganj","Kulaura","Rajnagar",

                "Sreemangal"],

                "Sunamganj" :["Bishwamvarpur","Chhatak","Derai","Dharampasha","Dowarabazar","Jagannathpur",

                "Jamalganj","Sulla","Sunamganj Sadar","Shanthiganj","Tahirpur"],

                "Sylhet" :["Sylhet Sadar","Beanibazar","Bishwanath","Dakshin Surma Upazila","Balaganj",

                "Companiganj","Fenchuganj","Golapganj","Gowainghat","Jaintiapur","Kanaighat",

                "Zakiganj","Nobigonj"]

        },"Mymensingh" :{

                "Jamalpur" :["Dewanganj Upazila","Baksiganj Upazila","Islampur Upazila","Jamalpur Sadar Upazila",

                "Madarganj Upazila","Melandaha Upazila","Sarishabari Upazila","Narundi Police I.C"],

                "Mymensingh" :["Bhaluka","Trishal","Haluaghat","Muktagachha","Dhobaura","Fulbaria","Gaffargaon",

                "Gauripur","Ishwarganj","Mymensingh Sadar","Nandail","Phulpur"],

                "Netrokona" :["Kendua Upazilla","Atpara Upazilla","Barhatta Upazilla","Durgapur Upazilla",

                "Kalmakanda Upazilla","Madan Upazilla","Mohanganj Upazilla","Netrakona-S Upazilla",

                "Purbadhala Upazilla","Khaliajuri Upazilla"],

                "Sherpur" :["Jhenaigati Upazila","Nakla Upazila","Nalitabari Upazila","Sherpur Sadar Upazila",

                "Sreebardi Upazila"]

        }

        }

        window.onload = function () {

            var countySel = document.getElementById("form_permanent_division"),

            stateSel = document.getElementById("form_permanent_district"),

            districtSel = document.getElementById("form_permanent_upazila");

            for (var country in stateObject) {

                countySel.options[countySel.options.length] = new Option(country, country);

            }

            countySel.onchange = function () {

                stateSel.length = 1; // remove all options bar first

                districtSel.length = 1; // remove all options bar first

                if (this.selectedIndex < 1) return; // done

                for (var state in stateObject[this.value]) {

                    stateSel.options[stateSel.options.length] = new Option(state, state);

                }

            }

            countySel.onchange(); // reset in case page is reloaded

            stateSel.onchange = function () {

                districtSel.length = 1; // remove all options bar first

                if (this.selectedIndex < 1) return; // done

                var district = stateObject[countySel.value][this.value];

                for (var i = 0; i < district.length; i++) {

                    districtSel.options[districtSel.options.length] = new Option(district[i], district[i]);

                }

            }


            //-----------------present
            var present_div = document.getElementById("form_present_division"),

                present_dis = document.getElementById("form_present_district"),

                present_upo = document.getElementById("form_present_upazila");

            for (var country in stateObject) {

                present_div.options[present_div.options.length] = new Option(country, country);

            }

            present_div.onchange = function () {

                present_dis.length = 1; // remove all options bar first

                present_upo.length = 1; // remove all options bar first

                if (this.selectedIndex < 1) return; // done

                for (var state in stateObject[this.value]) {

                    present_dis.options[present_dis.options.length] = new Option(state, state);

                }

            }

            present_div.onchange(); // reset in case page is reloaded

            present_dis.onchange = function () {

                present_upo.length = 1; // remove all options bar first

                if (this.selectedIndex < 1) return; // done

                var district = stateObject[present_div.value][this.value];

                for (var i = 0; i < district.length; i++) {

                    present_upo.options[present_upo.options.length] = new Option(district[i], district[i]);

                }

            }

        }
